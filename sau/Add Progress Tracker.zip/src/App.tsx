import { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { WelcomeView } from './components/WelcomeView';
import { RoadmapView } from './components/RoadmapView';
import { Chatbot } from './components/Chatbot';
import { ProfileDropdown } from './components/ProfileDropdown';
import { ProgressTracker } from './components/ProgressTracker';

interface RoadmapStep {
  title: string;
  description: string;
  completed: boolean;
}

export default function App() {
  const [view, setView] = useState<'welcome' | 'roadmap' | 'loading' | 'progress'>('welcome');
  const [inputValue, setInputValue] = useState('');
  const [currentTopic, setCurrentTopic] = useState('');
  const [roadmapSteps, setRoadmapSteps] = useState<RoadmapStep[]>([]);
  const [recentProjects, setRecentProjects] = useState<string[]>([]);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Apply neon theme to body
  useEffect(() => {
    document.body.classList.add('neon-theme');
    return () => {
      document.body.classList.remove('neon-theme');
    };
  }, []);

  const generateRoadmap = () => {
    const topic = inputValue.trim() || 'General Study Skills';
    setCurrentTopic(topic);
    setView('loading');

    // Simulate API delay
    setTimeout(() => {
      const steps: RoadmapStep[] = [
        {
          title: 'Step 1: Core Concepts & Fundamentals',
          description: `Research and define the basic terminology, history, and key players in ${topic}.`,
          completed: false,
        },
        {
          title: 'Step 2: Practical Application Exercises',
          description: `Complete hands-on tutorials or coding exercises related to ${topic}.`,
          completed: false,
        },
        {
          title: 'Step 3: Intermediate Deep Dive',
          description: 'Read advanced articles, case studies, and watch in-depth lectures.',
          completed: false,
        },
        {
          title: 'Step 4: Project and Portfolio Building',
          description: 'Design and execute a capstone project to demonstrate mastery.',
          completed: false,
        },
      ];

      setRoadmapSteps(steps);
      setView('roadmap');

      // Add to recent projects (max 5)
      setRecentProjects((prev) => {
        const updated = [topic, ...prev.filter((p) => p !== topic)];
        return updated.slice(0, 5);
      });
    }, 1500);
  };

  const handleNewProject = () => {
    setView('welcome');
    setInputValue('');
  };

  const handleProjectClick = (topic: string) => {
    setInputValue(topic);
    setView('welcome');
  };

  const handleToggleStep = (index: number) => {
    setRoadmapSteps((prev) =>
      prev.map((step, i) => (i === index ? { ...step, completed: !step.completed } : step))
    );
  };

  const handleProgressClick = () => {
    setView('progress');
  };

  const handleBackFromProgress = () => {
    setView('welcome');
  };

  return (
    <div className="min-h-screen text-white flex">
      {/* Main App Container */}
      <div className="flex flex-1">
        {/* Sidebar */}
        <Sidebar
          recentProjects={recentProjects}
          onNewProject={handleNewProject}
          onProjectClick={handleProjectClick}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-10 flex flex-col items-center justify-center relative overflow-y-auto">
          {/* Profile Icon */}
          <div
            id="profile-icon"
            className="absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center text-sm cursor-pointer z-50"
            style={{
              backgroundColor: 'var(--neon-purple)',
              border: '2px solid var(--neon-purple)',
              boxShadow: '0 0 15px rgba(128, 90, 213, 0.9)',
            }}
            onClick={() => setIsProfileOpen(!isProfileOpen)}
          >
            JD
          </div>

          {/* Profile Dropdown */}
          <ProfileDropdown 
            isOpen={isProfileOpen} 
            onClose={() => setIsProfileOpen(false)} 
            onProgressClick={handleProgressClick}
          />

          {/* Welcome View */}
          {view === 'welcome' && (
            <WelcomeView
              inputValue={inputValue}
              onInputChange={setInputValue}
              onGenerateRoadmap={generateRoadmap}
            />
          )}

          {/* Loading View */}
          {view === 'loading' && (
            <div className="flex flex-col items-center">
              <div
                className="w-10 h-10 border-4 rounded-full animate-spin mb-5"
                style={{
                  borderColor: 'var(--gray-700)',
                  borderTopColor: 'var(--neon-blue)',
                }}
              />
              <p style={{ color: 'var(--gray-400)' }}>Generating your roadmap...</p>
            </div>
          )}

          {/* Roadmap View */}
          {view === 'roadmap' && (
            <RoadmapView
              topic={currentTopic}
              steps={roadmapSteps}
              onBack={handleNewProject}
              onToggleStep={handleToggleStep}
            />
          )}

          {/* Progress Tracker View */}
          {view === 'progress' && (
            <ProgressTracker
              onBack={handleBackFromProgress}
              topics={recentProjects}
            />
          )}
        </main>
      </div>

      {/* Chatbot */}
      <Chatbot isOpen={isChatbotOpen} onToggle={() => setIsChatbotOpen(!isChatbotOpen)} />
    </div>
  );
}
