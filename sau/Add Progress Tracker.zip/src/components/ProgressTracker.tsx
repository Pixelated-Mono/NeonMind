import { useState } from 'react';
import { Clock, Calendar, Target, TrendingUp, Play, Pause, BarChart3 } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';

interface StudySession {
  id: string;
  topic: string;
  duration: number; // in minutes
  date: Date;
  completed: boolean;
}

interface TopicProgress {
  topic: string;
  totalTime: number; // in minutes
  sessions: number;
  targetTime: number; // in minutes
}

interface ProgressTrackerProps {
  onBack: () => void;
  topics: string[];
}

export function ProgressTracker({ onBack, topics }: ProgressTrackerProps) {
  const [studySessions, setStudySessions] = useState<StudySession[]>([
    {
      id: '1',
      topic: 'Machine Learning',
      duration: 45,
      date: new Date(Date.now() - 86400000 * 2),
      completed: true,
    },
    {
      id: '2',
      topic: 'Web Dev',
      duration: 60,
      date: new Date(Date.now() - 86400000),
      completed: true,
    },
    {
      id: '3',
      topic: 'Machine Learning',
      duration: 30,
      date: new Date(),
      completed: true,
    },
  ]);

  const [activeTimer, setActiveTimer] = useState<{
    topic: string;
    startTime: Date;
    isRunning: boolean;
  } | null>(null);
  const [timerMinutes, setTimerMinutes] = useState(0);
  const [selectedTopic, setSelectedTopic] = useState<string>('');

  // Calculate statistics
  const totalStudyTime = studySessions.reduce((acc, session) => acc + session.duration, 0);
  const totalSessions = studySessions.length;
  const averageSessionTime = totalSessions > 0 ? Math.round(totalStudyTime / totalSessions) : 0;

  // Calculate today's study time
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStudyTime = studySessions
    .filter((session) => {
      const sessionDate = new Date(session.date);
      sessionDate.setHours(0, 0, 0, 0);
      return sessionDate.getTime() === today.getTime();
    })
    .reduce((acc, session) => acc + session.duration, 0);

  // Calculate streak (consecutive days with study sessions)
  const calculateStreak = () => {
    const sortedDates = studySessions
      .map((s) => {
        const d = new Date(s.date);
        d.setHours(0, 0, 0, 0);
        return d.getTime();
      })
      .filter((v, i, a) => a.indexOf(v) === i)
      .sort((a, b) => b - a);

    let streak = 0;
    let currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);

    for (const date of sortedDates) {
      if (date === currentDate.getTime()) {
        streak++;
        currentDate.setDate(currentDate.getDate() - 1);
      } else if (date === currentDate.getTime() + 86400000) {
        // Skip if no session yesterday but continue checking
        break;
      } else {
        break;
      }
    }

    return streak;
  };

  // Calculate topic progress
  const topicProgress: TopicProgress[] = topics.map((topic) => {
    const topicSessions = studySessions.filter((s) => s.topic === topic);
    const totalTime = topicSessions.reduce((acc, s) => acc + s.duration, 0);
    return {
      topic,
      totalTime,
      sessions: topicSessions.length,
      targetTime: 300, // 5 hours target
    };
  });

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const startTimer = () => {
    if (!selectedTopic) return;
    setActiveTimer({
      topic: selectedTopic,
      startTime: new Date(),
      isRunning: true,
    });

    const interval = setInterval(() => {
      setTimerMinutes((prev) => prev + 1);
    }, 60000); // Update every minute

    return () => clearInterval(interval);
  };

  const stopTimer = () => {
    if (!activeTimer) return;

    const newSession: StudySession = {
      id: Date.now().toString(),
      topic: activeTimer.topic,
      duration: timerMinutes,
      date: new Date(),
      completed: true,
    };

    setStudySessions([...studySessions, newSession]);
    setActiveTimer(null);
    setTimerMinutes(0);
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-6">
      <div className="mb-6 flex items-center justify-between">
        <h2 className="text-black">Progress Tracker</h2>
        <Button onClick={onBack} variant="outline">
          ← Back to Dashboard
        </Button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Clock className="w-5 h-5 text-blue-600" />
            </div>
            <span className="text-sm text-gray-600">Total Study Time</span>
          </div>
          <p className="text-black mt-2">{formatTime(totalStudyTime)}</p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-green-100 rounded-lg">
              <Calendar className="w-5 h-5 text-green-600" />
            </div>
            <span className="text-sm text-gray-600">Study Streak</span>
          </div>
          <p className="text-black mt-2">{calculateStreak()} days</p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Target className="w-5 h-5 text-purple-600" />
            </div>
            <span className="text-sm text-gray-600">Total Sessions</span>
          </div>
          <p className="text-black mt-2">{totalSessions}</p>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-orange-100 rounded-lg">
              <TrendingUp className="w-5 h-5 text-orange-600" />
            </div>
            <span className="text-sm text-gray-600">Avg Session</span>
          </div>
          <p className="text-black mt-2">{formatTime(averageSessionTime)}</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Study Timer */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-5 h-5 text-gray-700" />
            <h3 className="text-black">Study Timer</h3>
          </div>

          {!activeTimer ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-600 mb-2">Select Topic</label>
                <select
                  className="w-full p-3 border border-gray-300 rounded-lg bg-white text-black"
                  value={selectedTopic}
                  onChange={(e) => setSelectedTopic(e.target.value)}
                >
                  <option value="">Choose a topic...</option>
                  {topics.map((topic) => (
                    <option key={topic} value={topic}>
                      {topic}
                    </option>
                  ))}
                </select>
              </div>
              <Button
                onClick={startTimer}
                disabled={!selectedTopic}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                <Play className="w-4 h-4 mr-2" />
                Start Study Session
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-center p-8 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">Studying: {activeTimer.topic}</p>
                <p className="text-black">{formatTime(timerMinutes)}</p>
              </div>
              <Button
                onClick={stopTimer}
                variant="destructive"
                className="w-full"
              >
                <Pause className="w-4 h-4 mr-2" />
                Stop Session
              </Button>
            </div>
          )}
        </Card>

        {/* Today's Progress */}
        <Card className="p-6">
          <h3 className="text-black mb-4">Today's Progress</h3>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Study Time</span>
              <span className="text-black">{formatTime(todayStudyTime)}</span>
            </div>
            <Progress value={(todayStudyTime / 180) * 100} className="h-2" />
            <p className="text-xs text-gray-500">Daily goal: 3 hours</p>
          </div>
        </Card>
      </div>

      {/* Topic Progress */}
      <Card className="p-6 mt-6">
        <h3 className="text-black mb-4">Progress by Topic</h3>
        <div className="space-y-4">
          {topicProgress.map((tp) => (
            <div key={tp.topic} className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-black">{tp.topic}</span>
                <span className="text-sm text-gray-600">
                  {formatTime(tp.totalTime)} / {formatTime(tp.targetTime)}
                </span>
              </div>
              <Progress value={(tp.totalTime / tp.targetTime) * 100} className="h-2" />
              <div className="flex justify-between text-xs text-gray-500">
                <span>{tp.sessions} sessions</span>
                <span>{Math.round((tp.totalTime / tp.targetTime) * 100)}% complete</span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Recent Sessions */}
      <Card className="p-6 mt-6">
        <h3 className="text-black mb-4">Recent Study Sessions</h3>
        <div className="space-y-3">
          {studySessions
            .slice()
            .reverse()
            .slice(0, 10)
            .map((session) => (
              <div
                key={session.id}
                className="flex justify-between items-center p-3 bg-gray-50 rounded-lg"
              >
                <div>
                  <p className="text-black">{session.topic}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(session.date).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
                <span className="text-black">{formatTime(session.duration)}</span>
              </div>
            ))}
        </div>
      </Card>
    </div>
  );
}
