import { useEffect, useRef } from 'react';

interface ProfileDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  onProgressClick: () => void;
}

export function ProfileDropdown({ isOpen, onClose, onProgressClick }: ProfileDropdownProps) {
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        const profileIcon = document.getElementById('profile-icon');
        if (profileIcon && !profileIcon.contains(event.target as Node)) {
          onClose();
        }
      }
    };

    if (isOpen) {
      document.addEventListener('click', handleClickOutside);
    }

    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      ref={dropdownRef}
      className="absolute top-16 right-3 w-48 rounded-lg z-50"
      style={{
        backgroundColor: 'var(--gray-800)',
        border: '1px solid var(--gray-700)',
        boxShadow: '0 4px 15px rgba(0, 0, 0, 0.5)',
      }}
    >
      {/* Top Section - Profile Circle */}
      <div className="p-4 border-b" style={{ borderColor: 'var(--gray-700)' }}>
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mx-auto cursor-pointer transition-all duration-200"
          style={{
            backgroundColor: 'var(--neon-purple)',
            border: '2px solid var(--neon-purple)',
            boxShadow: '0 0 15px rgba(128, 90, 213, 0.9)',
          }}
          onClick={() => {
            onProgressClick();
            onClose();
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'scale(1.05)';
            e.currentTarget.style.boxShadow = '0 0 20px rgba(128, 90, 213, 1)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)';
            e.currentTarget.style.boxShadow = '0 0 15px rgba(128, 90, 213, 0.9)';
          }}
        >
          <span className="text-white">JD</span>
        </div>
        <p className="text-center mt-2 text-xs" style={{ color: 'var(--gray-400)' }}>
          Click to view Progress
        </p>
      </div>

      {/* Bottom Section - Menu Items */}
      <div className="py-2">
        <a
          href="#"
          className="block px-4 py-2 text-sm no-underline transition-all duration-100"
          style={{ color: 'var(--light-text)' }}
          onClick={(e) => {
            e.preventDefault();
            console.log('Navigated to Profile page.');
            onClose();
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(76, 81, 191, 0.2)';
            e.currentTarget.style.color = 'white';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'transparent';
            e.currentTarget.style.color = 'var(--light-text)';
          }}
        >
          Profile
        </a>
        <a
          href="#"
          className="block px-4 py-2 text-sm no-underline transition-all duration-100"
          style={{ color: 'var(--light-text)' }}
          onClick={(e) => {
            e.preventDefault();
            console.log('Navigated to Settings page.');
            onClose();
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(76, 81, 191, 0.2)';
            e.currentTarget.style.color = 'white';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'transparent';
            e.currentTarget.style.color = 'var(--light-text)';
          }}
        >
          Settings
        </a>
        <a
          href="#"
          className="block px-4 py-2 text-sm no-underline transition-all duration-100"
          style={{ color: 'var(--light-text)' }}
          onClick={(e) => {
            e.preventDefault();
            console.log('Logged out user.');
            onClose();
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = 'rgba(76, 81, 191, 0.2)';
            e.currentTarget.style.color = 'white';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'transparent';
            e.currentTarget.style.color = 'var(--light-text)';
          }}
        >
          Logout
        </a>
      </div>
    </div>
  );
}
