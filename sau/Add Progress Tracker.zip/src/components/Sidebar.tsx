import { BookOpen } from 'lucide-react';

interface SidebarProps {
  recentProjects: string[];
  onNewProject: () => void;
  onProjectClick: (topic: string) => void;
}

export function Sidebar({ recentProjects, onNewProject, onProjectClick }: SidebarProps) {
  return (
    <aside className="w-64 p-6 border-r border-[var(--gray-800)] flex flex-col" style={{ backgroundColor: 'var(--neon-dark)' }}>
      <div className="mb-10 flex items-center">
        <BookOpen className="w-6 h-6 mr-2" style={{ color: 'var(--neon-blue)' }} />
        <h1 className="text-white">NeonMind</h1>
      </div>

      <button
        onClick={onNewProject}
        className="w-full px-4 py-3 rounded-xl border-none cursor-pointer transition-all duration-200 mb-8"
        style={{
          backgroundColor: 'var(--neon-blue)',
          boxShadow: '0 0 10px rgba(76, 81, 191, 0.7), 0 0 20px rgba(76, 81, 191, 0.5)',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = 'var(--neon-purple)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'var(--neon-blue)';
        }}
      >
        + New Project
      </button>

      <div className="flex-1">
        <h2 className="text-xs uppercase tracking-wider mb-2" style={{ color: 'var(--gray-400)' }}>
          Recent Projects
        </h2>
        {recentProjects.length === 0 ? (
          <p className="text-sm" style={{ color: 'var(--gray-500)' }}>
            No projects yet. Start your first roadmap!
          </p>
        ) : (
          <div className="flex flex-col">
            {recentProjects.map((project, index) => (
              <div
                key={index}
                className="py-2 text-sm cursor-pointer transition-colors duration-100"
                style={{ color: 'var(--light-text)' }}
                onClick={() => onProjectClick(project)}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = 'var(--neon-blue)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = 'var(--light-text)';
                }}
              >
                {project}
              </div>
            ))}
          </div>
        )}
      </div>
    </aside>
  );
}
