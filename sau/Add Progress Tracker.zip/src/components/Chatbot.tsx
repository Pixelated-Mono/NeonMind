import { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';

interface Message {
  text: string;
  isUser: boolean;
  timestamp: string;
}

interface ChatbotProps {
  isOpen: boolean;
  onToggle: () => void;
}

export function Chatbot({ isOpen, onToggle }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      text: 'Hi, how can I help you?',
      isUser: false,
      timestamp: 'now',
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  const formatTime = (date: Date) => {
    let hours = date.getHours();
    let minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    const minutesStr = minutes < 10 ? '0' + minutes : minutes;
    return hours + ':' + minutesStr + ' ' + ampm;
  };

  const sendMessage = () => {
    const messageText = inputValue.trim();
    if (messageText === '') return;

    const newMessage: Message = {
      text: messageText,
      isUser: true,
      timestamp: formatTime(new Date()),
    };

    setMessages([...messages, newMessage]);
    setInputValue('');

    // Simulate assistant reply
    setTimeout(() => {
      const replyMessage: Message = {
        text: `I received your message about: "${messageText}". I can help you create a roadmap for any topic!`,
        isUser: false,
        timestamp: formatTime(new Date()),
      };
      setMessages((prev) => [...prev, replyMessage]);
    }, 500);
  };

  return (
    <>
      {/* Toggle Button */}
      {!isOpen && (
        <button
          onClick={onToggle}
          className="fixed bottom-6 right-6 p-4 rounded-full border-none cursor-pointer z-50 transition-all duration-300"
          style={{
            backgroundColor: 'var(--neon-blue)',
            boxShadow: '0 0 10px rgba(76, 81, 191, 0.7)',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.boxShadow =
              '0 0 15px rgba(76, 81, 191, 1), 0 0 30px rgba(128, 90, 213, 0.5)';
            e.currentTarget.style.transform = 'scale(1.05)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.boxShadow = '0 0 10px rgba(76, 81, 191, 0.7)';
            e.currentTarget.style.transform = 'scale(1)';
          }}
        >
          <MessageCircle className="w-7 h-7 text-white" />
        </button>
      )}

      {/* Chatbot Container */}
      {isOpen && (
        <div
          className="fixed top-0 bottom-0 right-0 h-screen w-96 flex flex-col border-l overflow-hidden z-50 transition-all duration-400"
          style={{
            backgroundColor: 'rgba(15, 8, 33, 0.95)',
            borderColor: 'var(--gray-800)',
            boxShadow: '-2px 0 10px rgba(0, 0, 0, 0.8)',
            backdropFilter: 'blur(8px)',
          }}
        >
          {/* Header */}
          <div
            className="p-4 flex items-center border-b"
            style={{ borderColor: 'var(--gray-800)' }}
          >
            <div
              className="w-10 h-10 rounded-full mr-3"
              style={{
                backgroundColor: 'var(--neon-purple)',
                border: '2px solid var(--neon-purple)',
                boxShadow: '0 0 10px rgba(128, 90, 213, 0.7)',
              }}
            />
            <div className="flex-1">
              <p className="m-0 text-sm">Neon assistant</p>
              <p className="m-0 text-xs flex items-center" style={{ color: 'var(--green-online)' }}>
                <span
                  className="w-2 h-2 rounded-full mr-1"
                  style={{ backgroundColor: 'var(--green-online)' }}
                />
                Online
              </p>
            </div>
            <button
              onClick={onToggle}
              className="p-2 border-none bg-transparent cursor-pointer transition-colors duration-200"
              style={{ color: 'var(--gray-400)' }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = 'white';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'var(--gray-400)';
              }}
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`p-3 rounded-2xl max-w-[80%] w-fit ${
                  message.isUser ? 'ml-auto' : ''
                }`}
                style={{
                  backgroundColor: message.isUser
                    ? 'rgba(60, 20, 40, 0.9)'
                    : 'rgba(30, 20, 60, 0.9)',
                  border: message.isUser
                    ? '1px solid rgba(213, 63, 140, 0.5)'
                    : '1px solid rgba(76, 81, 191, 0.5)',
                  borderBottomRightRadius: message.isUser ? '0' : '1rem',
                  borderBottomLeftRadius: message.isUser ? '1rem' : '0',
                  color: 'var(--light-text)',
                  boxShadow: '0 2px 5px rgba(0, 0, 0, 0.5)',
                }}
              >
                <p className="m-0">{message.text}</p>
                <p className="m-0 mt-1 text-xs" style={{ color: 'var(--gray-500)' }}>
                  {message.timestamp}
                </p>
              </div>
            ))}
          </div>

          {/* Input Area */}
          <div
            className="p-4 border-t flex items-center"
            style={{ borderColor: 'var(--gray-800)' }}
          >
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  sendMessage();
                }
              }}
              placeholder="Type a message..."
              className="flex-1 px-4 py-3 rounded-xl border transition-all duration-200 outline-none"
              style={{
                backgroundColor: 'var(--gray-900)',
                borderColor: 'var(--gray-700)',
                color: 'white',
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = 'var(--neon-blue)';
                e.currentTarget.style.boxShadow = '0 0 0 1px var(--neon-blue)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = 'var(--gray-700)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            />
            <button
              onClick={sendMessage}
              className="ml-3 p-3 rounded-xl border-none cursor-pointer transition-colors duration-200"
              style={{
                backgroundColor: 'var(--neon-pink)',
                boxShadow: '0 0 8px rgba(213, 63, 140, 0.8), 0 0 16px rgba(213, 63, 140, 0.4)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--neon-purple)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--neon-pink)';
              }}
            >
              <Send className="w-6 h-6 text-white" />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
