import { useState } from 'react';
import { ArrowLeft, CheckCircle2, Circle } from 'lucide-react';
import { Progress } from './ui/progress';

interface RoadmapStep {
  title: string;
  description: string;
  completed: boolean;
}

interface RoadmapViewProps {
  topic: string;
  steps: RoadmapStep[];
  onBack: () => void;
  onToggleStep: (index: number) => void;
}

export function RoadmapView({ topic, steps, onBack, onToggleStep }: RoadmapViewProps) {
  const completedSteps = steps.filter((step) => step.completed).length;
  const progress = (completedSteps / steps.length) * 100;

  return (
    <div className="w-full max-w-3xl text-left pb-16">
      <h2
        className="mb-6"
        style={{
          color: 'var(--neon-blue)',
          textShadow: '0 0 5px rgba(76, 81, 191, 0.5)',
        }}
      >
        Roadmap: {topic}
      </h2>

      {/* Progress Tracker */}
      <div
        className="mb-8 p-6 rounded-xl"
        style={{
          backgroundColor: 'var(--gray-800)',
          border: '1px solid var(--gray-700)',
        }}
      >
        <div className="flex justify-between items-center mb-3">
          <h3 style={{ color: 'var(--neon-purple)' }}>Your Progress</h3>
          <span className="text-xl" style={{ color: 'var(--neon-blue)' }}>
            {completedSteps} / {steps.length}
          </span>
        </div>
        <Progress value={progress} className="h-3 mb-2" />
        <p className="text-sm" style={{ color: 'var(--gray-400)' }}>
          {progress === 100
            ? '🎉 Congratulations! You completed this roadmap!'
            : `${Math.round(progress)}% complete - Keep going!`}
        </p>
      </div>

      {/* Steps */}
      <div className="flex flex-col gap-5">
        {steps.map((step, index) => (
          <div
            key={index}
            className="p-4 rounded-xl transition-all duration-200 cursor-pointer"
            style={{
              backgroundColor: 'var(--gray-800)',
              borderLeft: step.completed
                ? '5px solid var(--green-online)'
                : '5px solid var(--neon-purple)',
              boxShadow: '0 2px 10px rgba(0, 0, 0, 0.4)',
              opacity: step.completed ? 0.7 : 1,
            }}
            onClick={() => onToggleStep(index)}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateX(4px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateX(0)';
            }}
          >
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-1">
                {step.completed ? (
                  <CheckCircle2
                    className="w-6 h-6"
                    style={{ color: 'var(--green-online)' }}
                  />
                ) : (
                  <Circle className="w-6 h-6" style={{ color: 'var(--neon-purple)' }} />
                )}
              </div>
              <div className="flex-1">
                <h3
                  className={step.completed ? 'line-through' : ''}
                  style={{ color: 'var(--neon-pink)', margin: 0 }}
                >
                  {step.title}
                </h3>
                <p
                  className={step.completed ? 'line-through' : ''}
                  style={{ color: 'var(--gray-400)', margin: 0 }}
                >
                  {step.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={onBack}
        className="mt-8 w-full px-4 py-3 rounded-xl border-none cursor-pointer transition-all duration-200 flex items-center justify-center gap-2"
        style={{
          backgroundColor: 'var(--neon-blue)',
          boxShadow: '0 0 10px rgba(76, 81, 191, 0.7)',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = 'var(--neon-purple)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'var(--neon-blue)';
        }}
      >
        <ArrowLeft className="w-5 h-5" />
        Start New Roadmap
      </button>
    </div>
  );
}
