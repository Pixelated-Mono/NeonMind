interface WelcomeViewProps {
  inputValue: string;
  onInputChange: (value: string) => void;
  onGenerateRoadmap: () => void;
}

export function WelcomeView({ inputValue, onInputChange, onGenerateRoadmap }: WelcomeViewProps) {
  const popularTopics = ['Machine Learning', 'Web Dev', 'Data Science', 'UI/UX'];

  return (
    <div className="text-center w-full max-w-3xl flex flex-col items-center">
      <h2 className="mb-4">
        Welcome to{' '}
        <span
          className="inline-block"
          style={{
            color: 'var(--neon-purple)',
            textShadow: '0 0 8px rgba(128, 90, 213, 0.8)',
          }}
        >
          NeonMind
        </span>
      </h2>
      <p className="mb-12" style={{ color: 'var(--gray-400)' }}>
        Turn any topic into a glowing learning roadmap ✨
      </p>

      <div className="w-full max-w-2xl flex gap-3 mb-12">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => onInputChange(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === 'Enter') {
              onGenerateRoadmap();
            }
          }}
          placeholder="What would you like to learn today?"
          className="flex-1 px-5 py-3 rounded-xl border transition-all duration-200 outline-none"
          style={{
            backgroundColor: 'var(--gray-800)',
            borderColor: 'var(--gray-700)',
            color: 'white',
          }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = 'var(--neon-blue)';
            e.currentTarget.style.boxShadow = '0 0 0 2px var(--neon-blue)';
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = 'var(--gray-700)';
            e.currentTarget.style.boxShadow = 'none';
          }}
        />
        <button
          onClick={onGenerateRoadmap}
          className="px-6 py-3 rounded-xl border-none cursor-pointer transition-all duration-200"
          style={{
            backgroundColor: 'var(--neon-purple)',
            boxShadow: '0 0 15px rgba(128, 90, 213, 0.9)',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = 'var(--neon-blue)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'var(--neon-purple)';
          }}
        >
          Generate Roadmap
        </button>
      </div>

      <div className="flex gap-4 items-center">
        <span style={{ color: 'var(--gray-400)' }}>Popular:</span>
        {popularTopics.map((topic) => (
          <span
            key={topic}
            onClick={() => onInputChange(topic)}
            className="px-3 py-1 text-sm rounded-full cursor-pointer transition-colors duration-200"
            style={{
              backgroundColor: 'var(--gray-800)',
              color: 'var(--neon-blue)',
              border: '1px solid rgba(76, 81, 191, 0.3)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--gray-700)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--gray-800)';
            }}
          >
            {topic}
          </span>
        ))}
      </div>
    </div>
  );
}
